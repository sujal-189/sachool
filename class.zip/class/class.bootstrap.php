<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script type="text/javascript" src="class/bootstrap.js"></script>
	<script type="text/javascript" src="class/jquery-1.11.1.js"></script>
        <script type="text/javascript" src="class/jquery-ui.js"></script>
	<link rel="stylesheet" type="text/css" href="class/bootstrap.css" />
        <link rel="stylesheet" type="text/css" href="class/jquery-ui.css" />
        <script type="text/javascript">
          $(function(){
              
             $(".datepicker").datepicker({ dateFormat: 'yy-mm-dd'}).val();  
          });
                  
            
              
            
            
            
        </script>    
</head>
<body class="bg-info" style="font-family: calibri,cambria;">

</body>
</html>